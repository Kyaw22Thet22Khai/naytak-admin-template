export { OrdersPage } from "./ordersPage";
