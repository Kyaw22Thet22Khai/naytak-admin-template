export { SettingsPage } from "./settingsPage";
