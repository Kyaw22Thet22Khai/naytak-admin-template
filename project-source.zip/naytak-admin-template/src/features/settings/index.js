export { SettingsPage } from "./settingsPage";
